class NewPair <S,T> {

	private S first;
	private T second;

	public NewPair(S a, T b) {
		first = a;
		second = b;
	}

	public S getFirst() { return first; }
	public T getSecond() { return second; }

}
