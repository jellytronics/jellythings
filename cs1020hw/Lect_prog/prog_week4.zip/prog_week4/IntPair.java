class IntPair {

	private int first, second;

	public IntPair(int a, int b) {
		first = a;
		second = b;
	}

	public int getFirst() { return first; }
	public int getSecond() { return second; }
}

