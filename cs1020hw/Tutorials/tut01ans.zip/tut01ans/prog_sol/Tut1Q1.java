// Tut1Q1.java
// Corrected version of tut1Q1.java
import java.util.*;

public class Tut1Q1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.print("Enter length of box: ");
		int boxLength = input.nextInt();
		System.out.print("Enter width of box : ");
		int boxWidth = input.nextInt();
		System.out.print("Enter volume of box: ");
		int boxVol = input.nextInt();

		double boxHeight = computeHeight(boxLength, boxWidth, boxVol);
		System.out.println("Height of box = " + boxHeight);
	}

	// Compute the height of a box given its length, width and volume
	public static double computeHeight(int len, int wid, int vol) {
		return (double) vol / (len * wid);
	}
}

