public class Snippet {

	public static void main(String[] args) {

		int i = 65;
		System.out.println("i = " + i);
		System.out.println("(char) i = " + (char) i);
		System.out.println();

		char ch = 'a';
		System.out.println("ch = " + ch);
		System.out.println("(int) ch = " + (int) ch);
		System.out.println();

		ch = '1';
		System.out.println("ch = " + ch);
		System.out.println("(int) ch = " + (int) ch);
	}

}
