class C {

	public static int m() {
		return 123;
	}

	public static int m(int a) {
		return 3 * a;
	}
	
	public static int m(int a, int b) {
		return a + b;
	}
	
	public static int m(double a, double b) {
		return (int) (a * b);
	}

}

