public class TestOverloading {

	public static void main(String[] args) {

		System.out.println(C.m());
		System.out.println(C.m(7));
		// System.out.println(C.m(3.5));
		System.out.println(C.m(10, 20));
		System.out.println(C.m(10, 20.0));

	}

}
