// CS1020 (AY2013/4 Semester 2)
// Take-home lab #1
// Name: 
// Matric. No.: 
// Lab group: 
// Write the program description below.
// It is mandatory to write program description at the top of every program.
// Marks will be awarded for this in sit-in labs.
// Please remove this line and its preceding 3 lines.

public class OverlapRectangles {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter 2 opposite vertices of 1st rectangle: ");
		Point rect1Vertex1 = new Point(sc.nextInt(), sc.nextInt());
		Point rect1Vertex2 = new Point(sc.nextInt(), sc.nextInt());

		System.out.print("Enter 2 opposite vertices of 2nd rectangle: ");
		Point rect2Vertex1 = new Point(sc.nextInt(), sc.nextInt());
		Point rect2Vertex2 = new Point(sc.nextInt(), sc.nextInt());

		// For testing. Remove or comment off the statement below after testing.
		printAllVertices(rect1Vertex1, rect1Vertex2, rect2Vertex1, rect2Vertex2);

	}

	// This method is provided for your testing.
	// To print the 2 opposite vertices of each of the 2 rectangles.
	public static void printAllVertices(Point r1V1, Point r1V2,
	                                    Point r2V1, Point r2V2) {
		System.out.println("1st rectangle vertex 1: " + r1V1);
		System.out.println("1st rectangle vertex 2: " + r1V2);
		System.out.println("2nd rectangle vertex 1: " + r2V1);
		System.out.println("2nd rectangle vertex 2: " + r2V2);
	}

}

