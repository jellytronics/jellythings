// CS1020 (AY2013/4 Semester 2)
// Take-home lab #2
// Name: 
// Matric. No.: 
// Lab group: 
// Write the program description below.
// It is mandatory to write program description at the top of every program.
// Marks will be awarded for this in sit-in labs.
// Please remove this line and its preceding 3 lines.

import java.util.*;

public class GoldHunter {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		MyMap map = new MyMap(sc);

		// To check before anything is done.
		// Remove the statement below after you have tested your program.
		map.display();

		// Fill in the code below


	}

	// Note: You should add some methods in this program.
	//       You should not do all the work in the main() method above.

}

