/*  
 * CS1020 (AY2013/4 Sem2)  
 * Sit-in Lab #A 
 * Author    :   
 * Matric no.:   
 * Lab group : 
 * Description of program:   
 */ 

import java.util.*;

/* Getting length of longest substring without repeated characters in a string */

public class LongestSubstring {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	}
}
